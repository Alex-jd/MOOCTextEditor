package spelling;

import java.util.List;
import java.util.Queue;
import java.util.Set;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;

/** 
 * An trie data structure that implements the Dictionary and the AutoComplete ADT
 * @author You
 *
 */
public class AutoCompleteDictionaryTrie implements  Dictionary, AutoComplete {

    private TrieNode root;
    private int size;
    public int temp_true,temp_false;
    

    public AutoCompleteDictionaryTrie()
	{
		root = new TrieNode();
	}
	
	
	/** Insert a word into the trie.
	 * For the basic part of the assignment (part 2), you should convert the 
	 * string to all lower case before you insert it. 
	 * 
	 * This method adds a word by creating and linking the necessary trie nodes 
	 * into the trie, as described outlined in the videos for this week. It 
	 * should appropriately use existing nodes in the trie, only creating new 
	 * nodes when necessary. E.g. If the word "no" is already in the trie, 
	 * then adding the word "now" would add only one additional node 
	 * (for the 'w').
	 * 
	 * @return true if the word was successfully added or false if it already exists
	 * in the dictionary.
	 */
	public boolean addWord(String word)
	{
	    //TODO: Implement this method.
		TrieNode currNode = root;
		TrieNode nextNode;
		String localWord = word.toLowerCase();
		//String[] strArr = localWord.split("");
		for (char c : localWord.toCharArray()) {
			//System.out.println(c);
			nextNode = currNode.insert(c);
			if (nextNode == null) {
				currNode = currNode.getChild(c);
				//nextNode = currNode.insert(c);
			}
			else {
				currNode = nextNode;
			}
		//printNode(currNode);	
		}
		if (!currNode.endsWord() ) {
			currNode.setEndsWord(true);
			temp_true ++;
			return true;
		}
		else {
			//System.out.println(currNode.endsWord());
			temp_false ++;
			return false;
		}
			    
	}
	
	/** 
	 * Return the number of words in the dictionary.  This is NOT necessarily the same
	 * as the number of TrieNodes in the trie.
	 */
	public int size()
	{
		size = 0;
		countOfWords(root);
	    //TODO: Implement this method
	    return size;
	}
	
	public void countOfWords(TrieNode curr)
 	{
		if (curr == null) 
 			return;
 		
 		if (curr.endsWord()){
 			//System.out.println(curr.getText());
 			size ++;
 		}
 		//System.out.println(curr.getText());
 		
 		TrieNode next = null;
 		for (Character c : curr.getValidNextCharacters()) {
 			next = curr.getChild(c);
 			countOfWords(next);
 		}
 		
 	}
	
	/** Returns whether the string is a word in the trie, using the algorithm
	 * described in the videos for this week. */
	@Override
	public boolean isWord(String s) 
	{
	    // TODO: Implement this method
		TrieNode curr = root;
		TrieNode nextNode;
		String localWord = s.toLowerCase();
		
		for (char c : localWord.toCharArray()) {
			nextNode = findWord(curr, c);
			if (nextNode == null) {
				return false;
			}
			else {
				curr = nextNode;
			}
		}
		
		if (curr.endsWord()) {
			return true;
		}
		else {
			return false;
		}
		
	}
	
	private TrieNode findWord(TrieNode curr, Character c) {
		for (Character localChar : curr.getValidNextCharacters()) {
			if (c == localChar) {
				return curr.getChild(c);
			}
		}
		
		return null;
	}

	/** 
     * Return a list, in order of increasing (non-decreasing) word length,
     * containing the numCompletions shortest legal completions 
     * of the prefix string. All legal completions must be valid words in the 
     * dictionary. If the prefix itself is a valid word, it is included 
     * in the list of returned words. 
     * 
     * The list of completions must contain 
     * all of the shortest completions, but when there are ties, it may break 
     * them in any order. For example, if there the prefix string is "ste" and 
     * only the words "step", "stem", "stew", "steer" and "steep" are in the 
     * dictionary, when the user asks for 4 completions, the list must include 
     * "step", "stem" and "stew", but may include either the word 
     * "steer" or "steep".
     * 
     * If this string prefix is not in the trie, it returns an empty list.
     * 
     * @param prefix The text to use at the word stem
     * @param numCompletions The maximum number of predictions desired.
     * @return A list containing the up to numCompletions best predictions
     */@Override
     public List<String> predictCompletions(String prefix, int numCompletions) 
     {
    	 // TODO: Implement this method
    	 // This method should implement the following algorithm:
    	 // 1. Find the stem in the trie.  If the stem does not appear in the trie, return an
    	 //    empty list
    	 /*if (prefix == "") {
    		 return null;
    	 }*/
    	List<String> temp = new LinkedList<String>();
    	Queue<TrieNode> q = new LinkedList<TrieNode>();
    	String lowCasePrefix = prefix.toLowerCase();
    	 //System.out.println(isWord(lowCasePrefix));
    	TrieNode curr = root;
 		//TrieNode nextNode;
 		//Define current node in the trie
 		if (curr.getText() == lowCasePrefix) {
 			//System.out.println("curr.getText " + curr.getText() + "here");
 		}
 		else {
 			for (char c : lowCasePrefix.toCharArray()) {
 				TrieNode nextNode = findWord(curr, c);
 	 			if (nextNode == null) {
 	 				return temp;
 	 			}
 	 			else {
 	 				curr = nextNode;
 	 			}
 			}
 		}
 		
 		q.add(curr);
 		int i = 0;
 		while(!q.isEmpty() && i < numCompletions) {
 			TrieNode tempCurr = q.remove();
 			if (tempCurr.endsWord() ) {
 				temp.add(tempCurr.getText() );
 				i++;
 				//System.out.println(tempCurr.getText() + " " + i);
 			}
 			try {
 				for (char c : tempCurr.getValidNextCharacters() ) {
 					q.add(tempCurr.getChild(c));
 				}
 			}
 			catch (NullPointerException e) {
 				//return null;
 			}
 		
 		}


    	 // 2. Once the stem is found, perform a breadth first search to generate completions
    	 //    using the following algorithm:
    	 //    Create a queue (LinkedList) and add the node that completes the stem to the back
    	 //       of the list.
    	 //    Create a list of completions to return (initially empty)
    	 //    While the queue is not empty and you don't have enough completions:
    	 //       remove the first Node from the queue
    	 //       If it is a word, add it to the completions list
    	 //       Add all of its child nodes to the back of the queue
    	 // Return the list of completions
    	 
         return temp;
     }

 	// For debugging
 	public void printTree()
 	{
 		printNode(root);
 	}
 	
 	/** Do a pre-order traversal from this node down */
 	public void printNode(TrieNode curr)
 	{
 		if (curr == null) 
 			return;
 		
 		//if (curr.endsWord()){
 			System.out.println(curr.getText());
 			//size ++;
 		//}
 		//System.out.println(curr.getText());
 		
 		TrieNode next = null;
 		for (Character c : curr.getValidNextCharacters()) {
 			next = curr.getChild(c);
 			printNode(next);
 		}
 	}
 	

	
}